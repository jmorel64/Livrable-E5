# Warning

The code in this repo is in no way intended for commercial or industrial use. The code contains deliberate bugs and the AI models are deliberately under-optimized.
This repo is for educational purposes only.

----

# Avertissement

Le code présent dans ce repo n'est absolument pas fait pour être utilisé dans un cadre commercial ou industriel. Le code comporte des bugs volontaires et les modèles d'IA sont volontairement sous-optimisés.
Ce repo ne sert que dans un but didactique.

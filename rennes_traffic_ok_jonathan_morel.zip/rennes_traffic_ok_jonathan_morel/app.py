from flask import Flask, render_template, request
import plotly.graph_objs as go
import plotly.express as px
import numpy as np

from keras.models import load_model

from src.get_data import GetData
from src.utils import create_figure, prediction_from_model 
import flask_monitoringdashboard as dashboard
import logging
from logging.handlers import RotatingFileHandler


app = Flask(__name__)

# Configuration du logger pour enregistrer les erreurs
if not app.debug:  # Active uniquement si l'application n'est pas en mode débogage
    file_handler = RotatingFileHandler('error.log', maxBytes=10240, backupCount=10)
    file_handler.setLevel(logging.ERROR)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    app.logger.addHandler(file_handler)


data_retriever = GetData(url="https://data.rennesmetropole.fr/api/explore/v2.1/catalog/datasets/etat-du-trafic-en-temps-reel/exports/json?lang=fr&timezone=Europe%2FBerlin&use_labels=true&delimiter=%3B")
data = data_retriever()

model = load_model('model.h5') 


@app.route('/', methods=['GET', 'POST'])
def index():
    app.logger.info("Accès à la page d'accueil")

    if request.method == 'POST':
        try:
            fig_map = create_figure(data)
            graph_json = fig_map.to_json()

            selected_hour = request.form['hour']
            app.logger.info(f"Heure sélectionnée : {selected_hour}")

            cat_predict = prediction_from_model(model, selected_hour)
            app.logger.info(f"Prédiction effectuée : {cat_predict}")

            color_pred_map = {0:[(f"Prédiction à {selected_hour}h : Libre"), "green"], 1:[(f"Prédiction à {selected_hour}h : Dense"), "orange"], 2:[(f"Prédiction à {selected_hour}h : Bloqué"), "red"]}

            return render_template('index.html', graph_json=graph_json, text_pred=color_pred_map[cat_predict][0], color_pred=color_pred_map[cat_predict][1])
        except Exception as e:
            app.logger.error("Erreur lors du traitement POST : %s", e)
            return "Erreur interne", 500
    else:
        fig_map = create_figure(data)
        graph_json = fig_map.to_json()

        return render_template('index.html', graph_json=graph_json)

# Initialisation du tableau de bord
dashboard.config.enable_logging=True
dashboard.config.monitor_level = 1
dashboard.bind(app)

if __name__ == '__main__':
    app.run(debug=True)

